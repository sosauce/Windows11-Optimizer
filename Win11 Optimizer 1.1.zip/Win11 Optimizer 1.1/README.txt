Make sure to backup your system ang regedit BEFORE MAKING ANY CHANGES TO YOUR COMPUTER. I will not be held responsable 
for any problems.